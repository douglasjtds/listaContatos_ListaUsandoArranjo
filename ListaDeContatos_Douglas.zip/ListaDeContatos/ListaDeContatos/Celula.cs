﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace ListaDeContatos
//{
//    public class Celula
//    {
//        public Celula primeiro, ultimo, pos;
//        readonly Object item;
//        readonly Celula prox;
//    }
//}